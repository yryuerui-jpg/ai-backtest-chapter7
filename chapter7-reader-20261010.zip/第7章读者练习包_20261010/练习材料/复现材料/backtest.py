"""Chapter 8: deterministic paper-only daily backtest. No brokerage dependencies."""
from pathlib import Path
from decimal import Decimal, ROUND_FLOOR
from datetime import datetime, timezone, date
from zoneinfo import ZoneInfo
import json, csv, hashlib, math, statistics, argparse

D=Decimal
ROOT=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_csv(path, rows):
    if not rows: return
    with Path(path).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def prepare(source_dir, data_dir):
    from openpyxl import load_workbook
    data_dir.mkdir(parents=True,exist_ok=True)
    raw=json.loads((source_dir/'yahoo_spy_raw.json').read_text())['chart']['result'][0]
    q=raw['indicators']['quote'][0];rows=[]
    for i,t in enumerate(raw['timestamp']):
        r={'date':datetime.fromtimestamp(t,ZoneInfo('America/New_York')).date().isoformat()}
        for k in ['open','high','low','close']:
            if q[k][i] is None: raise ValueError(f'missing {k}: {r["date"]}')
            r[k]=str(D(str(q[k][i])).quantize(D('.01')))
        r['volume']=q['volume'][i]
        if r['volume'] is None: raise ValueError('missing volume')
        if not D(r['low'])<=min(D(r['open']),D(r['close']))<=max(D(r['open']),D(r['close']))<=D(r['high']):raise ValueError('invalid OHLC')
        rows.append(r)
    assert len({r['date'] for r in rows})==len(rows)
    assert rows==sorted(rows,key=lambda r:r['date'])
    write_csv(data_dir/'spy_daily.csv',rows)
    ydiv={datetime.fromtimestamp(x['date'],ZoneInfo('America/New_York')).date().isoformat():D(str(x['amount'])) for x in raw['events']['dividends'].values()}
    divs=[]
    w=load_workbook(source_dir/'ssga_distributions.xlsx',data_only=True,read_only=True)
    for r in w.active.values:
        if len(r)>6 and r[1]=='SPY':
            ex=datetime.strptime(r[3],'%m/%d/%Y').date().isoformat()
            if '2014-01-01'<=ex<='2025-12-31':
                amount=sum(D(str(x).strip() or '0') if x is not None else D(0) for x in r[6:9])
                assert ex in ydiv,ex
                divs.append({'ex_date':ex,'pay_date':datetime.strptime(r[5],'%m/%d/%Y').date().isoformat(),'amount':str(amount),'yahoo_amount':str(ydiv[ex]),'difference':str(amount-ydiv[ex])})
    divs.sort(key=lambda r:r['ex_date']);assert len(divs)==len(ydiv)==48
    splits=raw.get('events',{}).get('splits',{})
    if splits:raise ValueError('SPY split event requires explicit point-in-time price normalization; unsupported input must not be ignored')
    write_csv(data_dir/'spy_dividends.csv',divs)
    qa={'price_rows':len(rows),'price_first':rows[0]['date'],'price_last':rows[-1]['date'],'dividend_rows':len(divs),'split_events':0,'dividend_max_abs_difference':str(max(abs(D(r['difference'])) for r in divs)),'price_normalization':'Yahoo floating point OHLC rounded to quoted US cents; no dividend adjustment','source_sha256':{'yahoo':sha(source_dir/'yahoo_spy_raw.json'),'ssga':sha(source_dir/'ssga_distributions.xlsx')}}
    (data_dir/'data_qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2));return qa

def load(data_dir):
    with (data_dir/'spy_daily.csv').open(encoding='utf-8-sig') as f: prices=list(csv.DictReader(f))
    with (data_dir/'spy_dividends.csv').open(encoding='utf-8-sig') as f: divs=list(csv.DictReader(f))
    for p in prices:
        for k in ['open','high','low','close']:p[k]=D(p[k])
    if any(prices[i]['date']>=prices[i+1]['date'] for i in range(len(prices)-1)):raise ValueError('dates not strictly ascending')
    if any(any(not p[k].is_finite() or p[k]<=0 for k in ['open','high','low','close']) for p in prices):raise ValueError('missing or invalid prices')
    return prices,divs

def run(prices,divs,window=50,bp=10,start='2015-01-01',end='2025-12-31',benchmark=False):
    cash=D(100000);qty=0;receivables=[];ledger=[];orders=[];trades=[];active=None
    exmap={r['ex_date']:r for r in divs};s=D(bp)/D(10000)
    first=True
    for i,p in enumerate(prices):
        day=p['date']
        if day<start or day>end:continue
        if i<window:raise ValueError('insufficient warmup')
        prev=prices[i-1];ma=sum(x['close'] for x in prices[i-window:i])/D(window)
        desired=(prev['close']>ma) if not benchmark else True
        prevqty=qty;before=cash;earned=D(0);paid=D(0)
        if day in exmap and qty:
            e=exmap[day];earned=D(qty)*D(e['amount'])
            receivables.append({'ex_date':day,'pay_date':e['pay_date'],'amount':earned,'trade_id':active['id']})
            active['dividends']+=earned
        action='持有' if qty else '空仓';signed=0;fill=D(0);slip=D(0)
        if desired and qty==0:
            fill=p['open']*(1+s);qty=int((cash/fill).to_integral_value(rounding=ROUND_FLOOR))
            if qty:
                signed=qty;cash-=D(qty)*fill;slip=D(qty)*p['open']*s;action='买入'
                active={'id':len(trades)+1,'entry_date':day,'entry_signal_date':prev['date'],'quantity':qty,'entry_price':fill,'entry_open':p['open'],'entry_cost':D(qty)*fill,'dividends':D(0),'entry_index':len(ledger),'buy_slippage':slip}
        elif not desired and qty:
            fill=p['open']*(1-s);signed=-qty;cash+=D(qty)*fill;slip=D(qty)*p['open']*s;action='卖出'
            t=dict(active);t.update({'exit_date':day,'exit_price':fill,'exit_open':p['open'],'price_pnl':D(qty)*(fill-t['entry_price']),'sell_slippage':slip,'holding_sessions':len(ledger)-t['entry_index'],'closed':True})
            t['net_pnl']=t['price_pnl']+t['dividends'];t['return']=t['net_pnl']/t['entry_cost'];trades.append(t);qty=0;active=None
        # Payment booked at end of day. Receivables continue to belong to a sold lot.
        unpaid=[]
        for e in receivables:
            if e['pay_date']<=day:paid+=e['amount']
            else:unpaid.append(e)
        receivables=unpaid;cash+=paid
        recv=sum((x['amount'] for x in receivables),D(0));equity=cash+D(qty)*p['close']+recv
        assert cash>=0 and qty>=0
        if signed:orders.append({'date':day,'signal_date':prev['date'],'previous_close':prev['close'],'previous_ma':ma,'desired_long':int(desired),'action':action,'quantity':abs(signed),'raw_open':p['open'],'fill':fill,'slippage':slip,'cash_after_trade':cash-paid})
        ledger.append({'date':day,'open':p['open'],'close':p['close'],'signal_date':prev['date'],'previous_close':prev['close'],'previous_ma':ma,'desired_long':int(desired),'opening_quantity':prevqty,'action':action,'signed_quantity':signed,'fill':fill,'slippage':slip,'dividend_earned':earned,'dividend_paid':paid,'cash_start':before,'cash_end':cash,'quantity_end':qty,'dividend_receivable':recv,'equity':equity})
        first=False
    if active:
        t=dict(active);t.update({'exit_date':'未平仓','exit_price':prices[[r['date'] for r in prices].index(ledger[-1]['date'])]['close'],'exit_open':None,'price_pnl':D(qty)*(ledger[-1]['close']-active['entry_price']),'sell_slippage':D(0),'holding_sessions':len(ledger)-active['entry_index'],'closed':False})
        t['net_pnl']=t['price_pnl']+t['dividends'];t['return']=t['net_pnl']/t['entry_cost'];trades.append(t)
    assert abs(sum(t['net_pnl'] for t in trades)-(ledger[-1]['equity']-D(100000)))<D('.00000001')
    return {'daily':ledger,'orders':orders,'trades':trades,'metrics':metrics(ledger,trades,window,bp,benchmark)}

def metrics(rows,trades,window,bp,benchmark):
    e=[100000.]+[float(r['equity']) for r in rows];peak=e[0];peak_i=0;mdd=0;low_i=0;start_i=0;rets=[]
    for i,x in enumerate(e):
        if x>=peak:peak=x;peak_i=i
        dd=x/peak-1
        if dd<mdd:mdd=dd;low_i=i;start_i=peak_i
        if i:rets.append(x/e[i-1]-1)
        if i:rows[i-1]['drawdown']=D(str(dd));rows[i-1]['running_peak']=D(str(peak))
    recovery=next((i for i in range(low_i+1,len(e)) if e[i]>=e[start_i]),None) if mdd<0 else 0
    labels=['期初']+[r['date'] for r in rows]
    closed=[t for t in trades if t['closed']];pnl=[float(t['net_pnl']) for t in closed];wins=[x for x in pnl if x>0];loss=[x for x in pnl if x<0]
    years=(date.fromisoformat(rows[-1]['date'])-date.fromisoformat(rows[0]['date'])).days/365.25
    returns=[float(t['return']) for t in closed]
    return {'window':window,'bp':bp,'benchmark':benchmark,'first':rows[0]['date'],'last':rows[-1]['date'],'sessions':len(rows),'end_equity':e[-1],'total_return':e[-1]/100000-1,'cagr':(e[-1]/100000)**(1/years)-1,'max_drawdown':mdd,'volatility':statistics.stdev(rets)*math.sqrt(252),'exposure':sum(r['quantity_end']>0 for r in rows)/len(rows),'orders':sum(r['signed_quantity']!=0 for r in rows),'closed_trades':len(closed),'open_trades':len(trades)-len(closed),'win_rate':len(wins)/len(closed) if closed else None,'profit_factor':sum(wins)/-sum(loss) if loss else None,'mean_trade_return':statistics.mean(returns) if returns else None,'median_trade_return':statistics.median(returns) if returns else None,'top5_positive_share':sum(sorted(wins,reverse=True)[:5])/sum(wins) if wins else None,'closed_pnl':sum(pnl),'open_pnl':sum(float(t['net_pnl']) for t in trades if not t['closed']),'cash':float(rows[-1]['cash_end']),'shares':rows[-1]['quantity_end'],'receivable':float(rows[-1]['dividend_receivable']),'dividend_earned':sum(float(r['dividend_earned']) for r in rows),'dividend_paid':sum(float(r['dividend_paid']) for r in rows),'slippage':sum(float(r['slippage']) for r in rows),'drawdown_peak':labels[start_i],'drawdown_trough':labels[low_i],'drawdown_recovery':labels[recovery] if recovery else '尚未恢复','recovery_sessions':recovery-start_i if recovery else None}

def serial(o):
    if isinstance(o,D):return float(o)
    raise TypeError(type(o))

def main():
    p=argparse.ArgumentParser();p.add_argument('--data-dir',type=Path,default=ROOT/'data');p.add_argument('--out-dir',type=Path,default=ROOT/'results');p.add_argument('--prepare',action='store_true');a=p.parse_args()
    from configuration import validate_config
    cfg=validate_config(json.loads((ROOT/'config.json').read_text()))
    if a.prepare:prepare(ROOT/'sources',a.data_dir)
    prices,divs=load(a.data_dir);a.out_dir.mkdir(parents=True,exist_ok=True)
    from verify import validate_calendar
    validate_calendar(prices,cfg['data_start'],cfg['end'])
    assert cfg['initial_cash_usd']==100000 and cfg['commission_usd']==0 and cfg['cash_interest']==0 and cfg['leverage']==1
    base=run(prices,divs,cfg['base_window'],cfg['base_slippage_bp_per_side'],cfg['start'],cfg['end'])
    bench=run(prices,divs,cfg['base_window'],cfg['base_slippage_bp_per_side'],cfg['start'],cfg['end'],benchmark=True)
    runs=[run(prices,divs,w,b,cfg['start'],cfg['end'])['metrics'] for w in cfg['windows'] for b in cfg['slippage_grid_bp_per_side']]
    benchmark_costs=[bench['metrics'] if bp==cfg['base_slippage_bp_per_side'] else run(prices,divs,cfg['base_window'],bp,cfg['start'],cfg['end'],benchmark=True)['metrics'] for bp in cfg['slippage_grid_bp_per_side']]
    write_csv(a.out_dir/'benchmark_costs.csv',benchmark_costs)
    periods=[]
    for st,en in cfg['subperiods']:
        for bh in [False,True]:periods.append(run(prices,divs,cfg['base_window'],cfg['base_slippage_bp_per_side'],start=st,end=en,benchmark=bh)['metrics'])
    for name,obj in [('strategy',base),('benchmark',bench)]:
        for key in ['daily','orders','trades']:write_csv(a.out_dir/f'{name}_{key}.csv',obj[key])
    write_csv(a.out_dir/'sensitivity.csv',runs);write_csv(a.out_dir/'subperiods.csv',periods)
    result={'created_at':datetime.now(timezone.utc).isoformat(),'config_sha256':sha(ROOT/'config.json'),'data_sha256':{p.name:sha(p) for p in a.data_dir.glob('*.csv')},'strategy':base['metrics'],'benchmark':bench['metrics'],'sensitivity':runs,'subperiods':periods}
    result['benchmark_costs']=benchmark_costs
    (a.out_dir/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=serial))
    (a.out_dir/'full_results.json').write_text(json.dumps({'strategy':base,'benchmark':bench},ensure_ascii=False,default=serial))
    print(json.dumps(result,ensure_ascii=False,indent=2,default=serial))
if __name__=='__main__':main()
