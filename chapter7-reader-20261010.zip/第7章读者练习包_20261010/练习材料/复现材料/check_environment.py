"""Check the interpreter, installed dependencies and required IANA time zone."""
import sys,json,platform
from importlib.metadata import version
if sys.version_info < (3,11):
    raise RuntimeError('Python 3.11 or newer is required')
import openpyxl,dateutil,tzdata
from zoneinfo import ZoneInfo
zone=ZoneInfo('America/New_York')
print(json.dumps({'passed':True,'python':sys.version,'platform':platform.platform(),'dependencies':{x:version(x) for x in ['openpyxl','python-dateutil','tzdata']},'zone':str(zone)},ensure_ascii=False,indent=2))
