"""Independent float ledger, exchange-calendar checks, and targeted failure tests."""
from pathlib import Path
import json, csv, math, statistics, hashlib
from datetime import date, timedelta
from decimal import Decimal as D
from dateutil.easter import easter
ROOT=Path(__file__).resolve().parent

def nth(y,m,wd,n):
    a=date(y,m,1);return a+timedelta(days=(wd-a.weekday())%7+7*(n-1))
def last(y,m,wd):
    a=date(y+int(m==12),m%12+1,1)-timedelta(days=1)
    return a-timedelta(days=(a.weekday()-wd)%7)
def observe(d):
    return d-timedelta(days=1) if d.weekday()==5 else d+timedelta(days=1) if d.weekday()==6 else d
def validate_calendar(prices,start='2014-01-01',end='2025-12-31'):
    if (start,end)!=('2014-01-01','2025-12-31'):
        raise ValueError('Calendar coverage is fixed to the teaching data range 2014-2025')
    holidays={date(2018,12,5),date(2025,1,9)}
    for y in range(2014,2027):
        ny=date(y,1,1)
        # NYSE leaves preceding Friday open when New Year's Day is Saturday.
        holidays.add(ny+timedelta(days=1) if ny.weekday()==6 else ny)
        holidays.update([nth(y,1,0,3),nth(y,2,0,3),easter(y)-timedelta(days=2),last(y,5,0),observe(date(y,7,4)),nth(y,9,0,1),nth(y,11,3,4),observe(date(y,12,25))])
        if y>=2022:holidays.add(observe(date(y,6,19)))
    start=date.fromisoformat(start);end=date.fromisoformat(end)
    expected=[]
    while start<=end:
        if start.weekday()<5 and start not in holidays:expected.append(start.isoformat())
        start+=timedelta(days=1)
    actual=[p['date'] for p in prices]
    if actual!=expected:raise ValueError(f'calendar mismatch missing={set(expected)-set(actual)}, extra={set(actual)-set(expected)}')
    return len(expected)

def independent(prices,divs,w,bp,st,en,bh=False):
    # Independently computed rolling signal and position transitions, using floats.
    close=[float(p['close']) for p in prices];cash=100000.;units=0;owed={};out=[];fills=[]
    actions={d['ex_date']:d for d in divs};fee=bp/10000
    for i,p in enumerate(prices):
        day=p['date']
        if not st<=day<=en:continue
        a=actions.get(day)
        if a and units:owed[a['pay_date']]=owed.get(a['pay_date'],0)+units*float(a['amount'])
        sig=bh or close[i-1]>statistics.mean(close[i-w:i])
        op=float(p['open'])
        if sig and units==0:
            units=math.floor(cash/(op*(1+fee)));cash-=units*op*(1+fee)
            if units:fills.append((day,units))
        elif not sig and units:
            cash+=units*op*(1-fee);fills.append((day,-units));units=0
        for pay in list(owed):
            if pay<=day:cash+=owed.pop(pay)
        out.append((day,cash,units,sum(owed.values()),cash+units*float(p['close'])+sum(owed.values())))
    return out,fills

def main():
    import backtest as b
    p,d=b.load(ROOT/'data');cfg=json.loads((ROOT/'config.json').read_text())
    from configuration import validate_config,scenario_specs
    validate_config(cfg)
    checks=[];n=validate_calendar(p,cfg['data_start'],cfg['end']);checks.append({'check':'complete exchange calendar 2014-2025','rows':n,'passed':True})
    maxdiff=0;nr=0
    specs=scenario_specs(cfg)
    for w,c,st,en,bh in specs:
        a=b.run(p,d,w,c,st,en,bh);x,f=independent(p,d,w,c,st,en,bh)
        assert [(v['date'],v['signed_quantity']) for v in a['daily'] if v['signed_quantity']]==f
        for aa,xx in zip(a['daily'],x):
            for field,k in [('cash_end',1),('quantity_end',2),('dividend_receivable',3),('equity',4)]:
                diff=abs(float(aa[field])-xx[k]);maxdiff=max(diff,maxdiff);assert diff<.000001
        nr+=1
    checks.append({'check':'independent float replay all configured scenarios, cash/quantity/dividend receivable/equity and all fills','runs':nr,'max_usd_difference':maxdiff,'passed':True})
    # Failure must not be treated as empty signal.
    for label,broken in [('missing first session',p[1:]),('missing last session',p[:-1]),('missing interior session',p[:260]+p[261:]),('duplicate session',p[:2]+p[1:]),('empty input',[])]:
        try:validate_calendar(broken)
        except ValueError:checks.append({'check':label+' rejected','passed':True})
        else:raise AssertionError(label+' accepted')
    synth=[{'date':f'2020-01-{i+1:02d}','open':D(x),'high':D(x),'low':D(x),'close':D(x)} for i,x in enumerate([10,10,10,11,12,8,8,9])]
    r=b.run(synth,[],3,0,'2020-01-04','2020-01-08')
    assert r['daily'][0]['signed_quantity']==0 # equality is flat
    assert r['daily'][1]['signed_quantity']>0 # previous close -> next open
    assert r['daily'][3]['signed_quantity']<0
    # Quantity at the preceding close earns the ex-date distribution, even after sale.
    dd=[{'ex_date':'2020-01-07','pay_date':'2020-01-08','amount':'1'}]
    z=b.run(synth,dd,3,0,'2020-01-04','2020-01-08')
    assert z['daily'][3]['dividend_earned']==D(8333) and z['daily'][3]['dividend_receivable']==D(8333)
    assert z['daily'][4]['dividend_paid']==D(8333) and z['daily'][4]['quantity_end']==0
    # End mark, not invented liquidation.
    t=b.run(synth,[],3,0,'2020-01-04','2020-01-05')
    assert t['trades'][-1]['closed']==False and len(t['orders'])==1
    # Higher execution cost changes fills and possibly affordable units.
    costly=b.run(synth,[],3,20,'2020-01-04','2020-01-05')
    assert costly['orders'][0]['fill']>t['orders'][0]['fill'] and costly['orders'][0]['quantity']<=t['orders'][0]['quantity']
    checks.append({'check':'synthetic unit cases: equality, entry, exit, dividend entitlement and later cash, higher cost, terminal open position','passed':True,'note':'synthetic values used only for program tests, never presented as market history'})
    base=b.run(p,d,cfg['base_window'],cfg['base_slippage_bp_per_side'],cfg['start'],cfg['end']);closed=[t for t in base['trades'] if t['closed']];pos=sorted([float(t['net_pnl']) for t in closed if t['net_pnl']>0],reverse=True)
    if pos:assert abs(sum(pos[:5])/sum(pos)-base['metrics']['top5_positive_share'])<1e-12
    else:assert base['metrics']['top5_positive_share'] is None
    eq=[100000.]+[float(x['equity']) for x in base['daily']];peaks=[max(eq[:i+1]) for i in range(len(eq))]
    assert abs(min(x/y-1 for x,y in zip(eq,peaks))-base['metrics']['max_drawdown'])<1e-12
    # Future-price perturbation leaves all prior daily equity values unchanged.
    future=[dict(x) for x in p];lastday=future[-1]
    for k in ['open','high','low','close']:lastday[k]*=D('1.01')
    altered=b.run(future,d,cfg['base_window'],cfg['base_slippage_bp_per_side'],cfg['start'],cfg['end'])
    assert [x['equity'] for x in altered['daily'][:-1]]==[x['equity'] for x in base['daily'][:-1]]
    checks.append({'check':'independent drawdown/concentration formulas, future perturbation does not affect earlier equity','passed':True})
    (ROOT/'results'/'verification.json').write_text(json.dumps({'all_passed':True,'total_scenarios_checked':nr,'checks':checks},ensure_ascii=False,indent=2))
    print(json.dumps({'all_passed':True,'scenarios':nr,'max_usd_difference':maxdiff,'checks':len(checks)},indent=2))
if __name__=='__main__':main()
