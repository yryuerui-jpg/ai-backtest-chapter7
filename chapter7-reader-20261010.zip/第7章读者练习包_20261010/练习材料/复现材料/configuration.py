"""Supported teaching configuration. Fixed rules must not silently be ignored."""
import math
FIXED = {'chapter': 8, 'title': 'AI辅助回测分析：验证策略与理解收益', 'frozen_at': '2026-10-08', 'ticker': 'SPY', 'data_start': '2014-01-01', 'start': '2015-01-01', 'end': '2025-12-31', 'initial_cash_usd': 100000, 'commission_usd': 0, 'cash_interest': 0, 'leverage': 1, 'signal': 'close[t] > mean(close[t-window+1:t+1])', 'execution': 'next regular session open; buy at open*(1+bp/10000), sell at open*(1-bp/10000)', 'position': 'integer shares, buy maximum affordable only on flat-to-long transition; do not top up existing position', 'dividends': 'prior-close shares earn dividend on ex-date; receivable enters equity on ex-date, cash paid at payment-date close and available next session; no automatic reinvestment', 'prices': 'unadjusted prices for signals and fills; split events explicitly handled, do not substitute dividend-adjusted OHLC', 'terminal': 'mark open position and unpaid dividend receivable; no forced terminal sale', 'benchmark': 'buy maximum affordable at first session open; hold, retain dividend cash; same slip and terminal accounting', 'subperiods': [['2015-01-01', '2019-12-31'], ['2020-01-01', '2022-12-31'], ['2023-01-01', '2025-12-31']], 'subperiod_initialization': 'each period independently starts with 100000 USD; use earlier observations only for warmup', 'interpretation': 'retrospective illustration, not untouched out-of-sample or prospective validation; no optimize-and-select', 'real_orders': False}
ALLOWED = {'base_window', 'windows', 'base_slippage_bp_per_side', 'slippage_grid_bp_per_side'}
def validate_config(cfg):
    if set(cfg) != set(FIXED) | ALLOWED:
        raise ValueError('Configuration keys differ from the supported teaching schema')
    for key, value in FIXED.items():
        if cfg[key] != value:
            raise ValueError(f'{key} is fixed in this teaching implementation; changing it requires implementation and independent validation')
    for key in ['windows', 'slippage_grid_bp_per_side']:
        if not isinstance(cfg[key], list) or not cfg[key]:
            raise ValueError(f'{key} must be a nonempty list')
        if len(set(cfg[key])) != len(cfg[key]):
            raise ValueError(f'{key} must not contain duplicates')
    for w in [cfg['base_window']] + cfg['windows']:
        if type(w) is not int or not 1 <= w <= 250:
            raise ValueError('MA windows must be integers between 1 and 250 sessions')
    for bp in [cfg['base_slippage_bp_per_side']] + cfg['slippage_grid_bp_per_side']:
        if type(bp) not in (int, float) or not math.isfinite(bp) or not 0 <= bp <= 100:
            raise ValueError('Teaching cost must be finite, between 0 and 100 bp per side')
    return cfg

def scenario_specs(cfg):
    validate_config(cfg)
    w, bp, st, en = (cfg[k] for k in ['base_window','base_slippage_bp_per_side','start','end'])
    specs = [(x,c,st,en,False) for x in cfg['windows'] for c in cfg['slippage_grid_bp_per_side']]
    specs += [(w,c,st,en,True) for c in cfg['slippage_grid_bp_per_side']]
    specs += [(w,bp,st,en,False),(w,bp,st,en,True)]
    specs += [(w,bp,a,z,bh) for a,z in cfg['subperiods'] for bh in [False,True]]
    return list(dict.fromkeys(specs))
