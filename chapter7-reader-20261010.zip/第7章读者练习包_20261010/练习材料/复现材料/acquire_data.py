"""Fetch source snapshots for personal reproduction; no account or broker access."""
from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,hashlib,argparse
ROOT=Path(__file__).resolve().parent
URLS={'yahoo':('https://query1.finance.yahoo.com/v8/finance/chart/SPY?period1=1388534400&period2=1767225600&interval=1d&events=div%2Csplits&includeAdjustedClose=true','yahoo_spy_raw.json'),'ssga':('https://www.ssga.com/library-content/products/fund-data/etfs/us/spdr-etf-historical-distributions.xlsx','ssga_distributions.xlsx')}
def main():
    a=argparse.ArgumentParser();a.add_argument('--replace',action='store_true');opt=a.parse_args();out=ROOT/'sources';out.mkdir(exist_ok=True)
    for name,(url,fn) in URLS.items():
        target=out/fn
        if target.exists() and not opt.replace:raise FileExistsError(f'{target} exists; preserve it or explicitly pass --replace')
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=60) as r:blob=r.read()
        if name=='yahoo':assert json.loads(blob)['chart']['result']
        else:assert blob[:2]==b'PK'
        target.write_bytes(blob)
        (out/f'{name}_receipt.json').write_text(json.dumps({'url':url,'retrieved_at':datetime.now(timezone.utc).isoformat(),'sha256':hashlib.sha256(blob).hexdigest()},indent=2))
        print(name,len(blob),'bytes saved; verify against the supplied original receipt before comparing results')
if __name__=='__main__':main()
