"""只复算保存交易的局部示例；不下载或重新运行回测。"""
from pathlib import Path
from decimal import Decimal
import csv,json,hashlib
ROOT=Path(__file__).resolve().parent
source=ROOT.parent/'复现材料/reference_results/strategy_trades.csv'
with source.open(encoding='utf-8-sig',newline='') as f:
    rows=[r for r in csv.DictReader(f) if r['id'] in ['1','2','3']]
assert [r['id'] for r in rows]==['1','2','3']
D=Decimal
pnl=sum(D(r['net_pnl']) for r in rows)
cost=sum(D(r['buy_slippage'])+D(r['sell_slippage']) for r in rows)
assert pnl==D('-4359.66389') and cost==D('583.87389')
assert all(D(r['dividends'])==0 for r in rows)
result={'operation':'从参考交易表复算前三笔；不是新策略回测','source':'复现材料/reference_results/strategy_trades.csv','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'trades':[{'id':r['id'],'entry_date':r['entry_date'],'exit_date':r['exit_date'],'net_pnl_usd':r['net_pnl'],'execution_cost_usd':str(D(r['buy_slippage'])+D(r['sell_slippage']))} for r in rows],'total_net_pnl_usd':str(pnl),'total_execution_cost_usd':str(cost),'limitations':'局部交易解释；不能归因为全期收益差距，也不是零成本重跑。'}
(ROOT/'阅读示例.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
